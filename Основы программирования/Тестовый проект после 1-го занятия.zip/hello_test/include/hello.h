#pragma once

void greet(const char* name);
