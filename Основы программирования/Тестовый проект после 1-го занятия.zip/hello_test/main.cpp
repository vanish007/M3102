#include "hello.h"


int main(int argc, char* argv[]) {
    if (argc > 1) {
        greet(argv[1]);
    } else {
        greet("ITMO");
    }

    return 0;
}
