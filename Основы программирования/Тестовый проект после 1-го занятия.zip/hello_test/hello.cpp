#include <iostream>
#include "hello.h"


void greet(const char* name) {
    std::cout << "Hello, " << name << "!" << std::endl;
}
